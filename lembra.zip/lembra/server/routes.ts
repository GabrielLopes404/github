import express, { type Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import session from "express-session";
import connectPgSimple from "connect-pg-simple";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import rateLimit from "express-rate-limit";
import helmet from "helmet";
import cors from "cors";
import crypto from "crypto";
import { eq, desc, sql } from "drizzle-orm";
import { db } from "./db";
import { storage } from "./storage";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";
import bcrypt from "bcryptjs";
import XLSX from "xlsx";
import { Parser } from "json2csv";
import { getCsrfToken, csrfProtection } from "./csrf";
import { getPaginationParams, createPaginatedResponse } from "./pagination";
import { healthCheck, liveness, readiness } from "./health";
import { register as metricsRegister } from "./metrics";
import { validateDocument, normalizeDocument } from "./document-validator";
import { generate2FASecret, verify2FAToken } from "./auth-2fa";
import { getActiveSessions, revokeSession } from "./session-manager";
import * as schema from "@shared/schema";
import {
  insertUserSchema,
  insertOrganizationSchema,
  createCustomerSchema,
  createInvoiceSchema,
  createCategorySchema,
  createBankAccountSchema,
  createCostCenterSchema,
  createTagSchema,
  createTransactionSchema,
  createDocumentSchema,
  createReconciliationSchema,
  type User,
  type Subscription,
} from "@shared/schema";

// Extend Express session to include user
declare global {
  namespace Express {
    interface User {
      id: string;
      username: string;
      email: string;
      name: string;
      organizationId: string | null;
      role: "OWNER" | "ADMIN" | "CUSTOMER";
      emailVerified: boolean;
    }
  }
}

// Middleware to check if user is authenticated
function isAuthenticated(req: Request, res: Response, next: NextFunction) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
}

// Middleware to check if user is admin or owner
function isAdminOrOwner(req: Request, res: Response, next: NextFunction) {
  if (req.isAuthenticated() && (req.user!.role === "ADMIN" || req.user!.role === "OWNER")) {
    return next();
  }
  res.status(403).json({ message: "Forbidden: Admin or Owner access required" });
}

// Middleware to check if user is owner (only OWNER can promote/demote)
function isOwner(req: Request, res: Response, next: NextFunction) {
  if (req.isAuthenticated() && req.user!.role === "OWNER") {
    return next();
  }
  res.status(403).json({ message: "Forbidden: Owner access required" });
}

// Validation middleware
function validateBody(schema: z.ZodSchema) {
  return (req: Request, res: Response, next: NextFunction) => {
    try {
      schema.parse(req.body);
      next();
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: fromZodError(error).message });
      } else {
        res.status(400).json({ message: "Invalid request body" });
      }
    }
  };
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Security middleware
  app.use(helmet({
    contentSecurityPolicy: false, // Vite handles CSP in dev
  }));
  
  // CORS configuration
  app.use(cors({
    origin: process.env.NODE_ENV === "production" 
      ? process.env.ALLOWED_ORIGINS?.split(',') || []
      : true,
    credentials: true,
  }));

  // Rate limiting
  const limiter = rateLimit({
    windowMs: 1 * 60 * 1000, // 1 minute
    max: 100, // 100 requests per minute
    message: "Muitas requisições, tente novamente em breve.",
    standardHeaders: true,
    legacyHeaders: false,
  });

  const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 5, // 5 login attempts
    message: "Muitas tentativas de login, tente novamente em 15 minutos.",
    skipSuccessfulRequests: true,
  });

  app.use("/api/", limiter);

  // Session configuration with PostgreSQL store
  const PgSession = connectPgSimple(session);
  
  if (!process.env.SESSION_SECRET) {
    throw new Error("SESSION_SECRET environment variable is required");
  }

  app.use(
    session({
      store: new PgSession({
        conObject: {
          connectionString: process.env.DATABASE_URL,
        },
        tableName: 'session',
        createTableIfMissing: true,
      }),
      secret: process.env.SESSION_SECRET,
      resave: false,
      saveUninitialized: false,
      cookie: {
        secure: process.env.NODE_ENV === "production",
        httpOnly: true,
        maxAge: 1000 * 60 * 60 * 24 * 7, // 7 days
        sameSite: process.env.NODE_ENV === "production" ? "strict" : "lax",
      },
    })
  );

  // Middleware to capture IP and User-Agent in session
  app.use((req: Request, res: Response, next: NextFunction) => {
    if (req.session) {
      const session = req.session as any;
      session.cookie = session.cookie || {};
      session.cookie.ipAddress = req.ip || req.socket.remoteAddress || 'Unknown';
      session.cookie.userAgent = req.headers['user-agent'] || 'Unknown';
    }
    next();
  });

  // Passport configuration
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(
      { usernameField: "email" },
      async (email, password, done) => {
        try {
          const user = await storage.getUserByEmail(email);
          if (!user) {
            return done(null, false, { message: "Invalid credentials" });
          }

          const isValid = await bcrypt.compare(password, user.password);
          if (!isValid) {
            return done(null, false, { message: "Invalid credentials" });
          }

          return done(null, {
            id: user.id,
            username: user.username,
            email: user.email,
            name: user.name || user.username,
            organizationId: user.organizationId,
            role: user.role as "OWNER" | "ADMIN" | "CUSTOMER",
            emailVerified: user.emailVerified || false,
          });
        } catch (error) {
          return done(error);
        }
      }
    )
  );

  passport.serializeUser((user, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: string, done) => {
    try {
      const user = await storage.getUser(id);
      if (!user) {
        return done(null, false);
      }
      done(null, {
        id: user.id,
        username: user.username,
        email: user.email,
        name: user.name || user.username,
        organizationId: user.organizationId,
        role: user.role as "OWNER" | "ADMIN" | "CUSTOMER",
        emailVerified: user.emailVerified || false,
      });
    } catch (error) {
      done(error);
    }
  });

  // CSRF TOKEN ROUTE (must be before CSRF protection middleware)
  app.get("/api/csrf-token", getCsrfToken);

  // Apply CSRF protection to all state-changing routes (POST, PUT, DELETE, PATCH)
  app.use("/api/", (req: Request, res: Response, next: NextFunction) => {
    // Skip CSRF check for GET, HEAD, OPTIONS (safe methods)
    if (req.method === 'GET' || req.method === 'HEAD' || req.method === 'OPTIONS') {
      return next();
    }
    // Apply CSRF protection to ALL state-changing requests
    return csrfProtection(req, res, next);
  });

  // AUTH ROUTES
  // Register
  app.post("/api/auth/register", authLimiter, async (req: Request, res: Response) => {
    try {
      let { email, password, username, name, organizationName, personType, document, phone } = req.body;

      // Normalize inputs on server-side to prevent bypass
      email = email?.toLowerCase().trim();
      username = username?.toLowerCase().trim();
      name = name?.trim();
      organizationName = organizationName?.trim();
      document = document ? normalizeDocument(document) : null;
      phone = phone?.trim();
      const validPersonType = (personType === "PF" || personType === "PJ") ? personType : "PF";

      // Validate inputs
      if (!email || !password || !username || !name) {
        return res.status(400).json({ message: "Todos os campos são obrigatórios" });
      }

      // Validate document (CPF/CNPJ) if provided
      if (document) {
        const docValidation = validateDocument(document, validPersonType);
        if (!docValidation.valid) {
          return res.status(400).json({ message: docValidation.message });
        }
      }

      // Validate username format (only lowercase letters, numbers, underscore)
      if (!/^[a-z0-9_]{3,}$/.test(username)) {
        return res.status(400).json({ message: "Nome de usuário inválido. Use apenas letras minúsculas, números e underscore (mínimo 3 caracteres)" });
      }

      // Validate email format
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        return res.status(400).json({ message: "Email inválido" });
      }

      // Check if user with email already exists
      const existingUserByEmail = await storage.getUserByEmail(email);
      if (existingUserByEmail) {
        return res.status(400).json({ message: "Este email já está em uso" });
      }

      // Check if user with username already exists (case-insensitive)
      const existingUserByUsername = await storage.getUserByUsername(username);
      if (existingUserByUsername) {
        return res.status(400).json({ message: "Este nome de usuário já está em uso" });
      }

      // Hash password with 12 rounds for security
      const hashedPassword = await bcrypt.hash(password, 12);

      // Create organization first
      const organization = await storage.createOrganization({
        name: organizationName || `${name}'s Organization`,
        email,
        document: document || null,
        phone: phone || null,
        personType: validPersonType,
      });

      // Create user with CUSTOMER role (first user of their organization)
      const user = await storage.createUser({
        username,
        email,
        password: hashedPassword,
        name,
        organizationId: organization.id,
        role: "CUSTOMER",
        emailVerified: false,
      });

      // Log activity
      await storage.createActivity({
        organizationId: organization.id,
        userId: user.id,
        action: "user_registered",
        entityType: "user",
        entityId: user.id,
        details: JSON.stringify({ email }),
      });

      // Auto login after registration with session regeneration for security
      // Regenerate session FIRST to prevent session fixation attacks
      req.session.regenerate((regenerateErr) => {
        if (regenerateErr) {
          console.error("Session regeneration error:", regenerateErr);
          return res.status(500).json({ message: "Registration successful but session creation failed" });
        }
        
        // THEN login the user to the NEW session
        req.login(
          {
            id: user.id,
            username: user.username,
            email: user.email,
            name: user.name || user.username,
            organizationId: user.organizationId,
            role: user.role as "OWNER" | "ADMIN" | "CUSTOMER",
            emailVerified: user.emailVerified || false,
          },
          (loginErr) => {
            if (loginErr) {
              return res.status(500).json({ message: "Registration successful but login failed" });
            }
            
            res.json({
              user: {
                id: user.id,
                username: user.username,
                email: user.email,
                name: user.name,
                organizationId: user.organizationId,
                role: user.role,
                emailVerified: user.emailVerified,
              },
            });
          }
        );
      });
    } catch (error) {
      console.error("Registration error:", error);
      res.status(500).json({ message: "Registration failed" });
    }
  });

  // Login
  app.post("/api/auth/login", authLimiter, (req: Request, res: Response, next: NextFunction) => {
    passport.authenticate("local", (err: any, user: any, info: any) => {
      if (err) {
        return res.status(500).json({ message: "Login failed" });
      }
      if (!user) {
        return res.status(401).json({ message: info?.message || "Invalid credentials" });
      }
      
      // Regenerate session FIRST to prevent session fixation attacks
      req.session.regenerate((regenerateErr) => {
        if (regenerateErr) {
          console.error("Session regeneration error:", regenerateErr);
          return res.status(500).json({ message: "Session regeneration failed" });
        }
        
        // THEN login the user to the NEW session
        req.login(user, (loginErr) => {
          if (loginErr) {
            return res.status(500).json({ message: "Login failed" });
          }
          
          res.json({ user });
        });
      });
    })(req, res, next);
  });

  // Admin Login - only for ADMIN and OWNER roles
  app.post("/api/auth/admin/login", authLimiter, (req: Request, res: Response, next: NextFunction) => {
    passport.authenticate("local", (err: any, user: any, info: any) => {
      if (err) {
        return res.status(500).json({ message: "Login failed" });
      }
      if (!user) {
        return res.status(401).json({ message: info?.message || "Invalid credentials" });
      }
      
      // Check if user is ADMIN or OWNER
      if (user.role !== "ADMIN" && user.role !== "OWNER") {
        return res.status(403).json({ message: "Acesso negado. Apenas administradores podem acessar esta área." });
      }
      
      // Regenerate session FIRST to prevent session fixation attacks
      req.session.regenerate((regenerateErr) => {
        if (regenerateErr) {
          console.error("Session regeneration error:", regenerateErr);
          return res.status(500).json({ message: "Session regeneration failed" });
        }
        
        // THEN login the user to the NEW session
        req.login(user, (loginErr) => {
          if (loginErr) {
            return res.status(500).json({ message: "Login failed" });
          }
          
          res.json({ user, message: "Login administrativo realizado com sucesso" });
        });
      });
    })(req, res, next);
  });

  // Logout
  app.post("/api/auth/logout", (req: Request, res: Response) => {
    req.logout(() => {
      res.json({ message: "Logged out successfully" });
    });
  });

  // Get current user
  app.get("/api/auth/me", isAuthenticated, (req: Request, res: Response) => {
    res.json({ user: req.user });
  });

  // USER MANAGEMENT ROUTES (OWNER ONLY)
  // Promote user to ADMIN
  app.post("/api/users/:id/promote", isAuthenticated, isOwner, csrfProtection, async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      
      // Get the user to be promoted
      const targetUser = await storage.getUserById(id);
      if (!targetUser) {
        return res.status(404).json({ message: "Usuário não encontrado" });
      }

      // Check if user belongs to the same organization
      if (targetUser.organizationId !== req.user!.organizationId) {
        return res.status(403).json({ message: "Não é possível promover usuários de outras organizações" });
      }

      // Check if user is already ADMIN or OWNER
      if (targetUser.role === "ADMIN") {
        return res.status(400).json({ message: "Usuário já é ADMIN" });
      }
      if (targetUser.role === "OWNER") {
        return res.status(400).json({ message: "Não é possível alterar o role de um OWNER" });
      }

      // Promote to ADMIN
      await storage.updateUser(id, { role: "ADMIN" });

      // Log audit
      await db.insert(schema.auditLogs).values({
        userId: req.user!.id,
        organizationId: req.user!.organizationId,
        action: "promote_user",
        entityType: "user",
        entityId: id,
        oldValue: JSON.stringify({ role: targetUser.role }),
        newValue: JSON.stringify({ role: "ADMIN" }),
        ipAddress: req.ip,
        userAgent: req.get('user-agent'),
      });

      res.json({ 
        message: "Usuário promovido para ADMIN com sucesso",
        user: { ...targetUser, role: "ADMIN" }
      });
    } catch (error) {
      console.error("Error promoting user:", error);
      res.status(500).json({ message: "Erro ao promover usuário" });
    }
  });

  // Demote ADMIN to CUSTOMER
  app.post("/api/users/:id/demote", isAuthenticated, isOwner, csrfProtection, async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      
      // Get the user to be demoted
      const targetUser = await storage.getUserById(id);
      if (!targetUser) {
        return res.status(404).json({ message: "Usuário não encontrado" });
      }

      // Check if user belongs to the same organization
      if (targetUser.organizationId !== req.user!.organizationId) {
        return res.status(403).json({ message: "Não é possível rebaixar usuários de outras organizações" });
      }

      // Check if user is OWNER (cannot demote OWNER)
      if (targetUser.role === "OWNER") {
        return res.status(400).json({ message: "Não é possível rebaixar um OWNER" });
      }

      // Check if user is already CUSTOMER
      if (targetUser.role === "CUSTOMER") {
        return res.status(400).json({ message: "Usuário já é CUSTOMER" });
      }

      // Demote to CUSTOMER
      await storage.updateUser(id, { role: "CUSTOMER" });

      // Log audit
      await db.insert(schema.auditLogs).values({
        userId: req.user!.id,
        organizationId: req.user!.organizationId,
        action: "demote_user",
        entityType: "user",
        entityId: id,
        oldValue: JSON.stringify({ role: targetUser.role }),
        newValue: JSON.stringify({ role: "CUSTOMER" }),
        ipAddress: req.ip,
        userAgent: req.get('user-agent'),
      });

      res.json({ 
        message: "Usuário rebaixado para CUSTOMER com sucesso",
        user: { ...targetUser, role: "CUSTOMER" }
      });
    } catch (error) {
      console.error("Error demoting user:", error);
      res.status(500).json({ message: "Erro ao rebaixar usuário" });
    }
  });

  // List all users in organization (ADMIN and OWNER only)
  app.get("/api/users", isAuthenticated, isAdminOrOwner, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "Organização não encontrada" });
      }

      const users = await storage.getUsersByOrganization(req.user!.organizationId);
      
      // Remove sensitive data
      const sanitizedUsers = users.map(user => ({
        id: user.id,
        username: user.username,
        email: user.email,
        name: user.name,
        role: user.role,
        emailVerified: user.emailVerified,
        createdAt: user.createdAt,
      }));

      res.json({ users: sanitizedUsers });
    } catch (error) {
      console.error("Error listing users:", error);
      res.status(500).json({ message: "Erro ao listar usuários" });
    }
  });

  // SUBSCRIPTION PLANS ROUTES (OWNER ONLY)
  // Get all subscription plans
  app.get("/api/subscription-plans", isAuthenticated, isOwner, async (req: Request, res: Response) => {
    try {
      const plans = await db.select().from(schema.subscriptionPlans);
      res.json({ plans });
    } catch (error) {
      console.error("Error fetching subscription plans:", error);
      res.status(500).json({ message: "Erro ao buscar planos de assinatura" });
    }
  });

  // Create subscription plan (OWNER only)
  app.post("/api/subscription-plans", isAuthenticated, isOwner, csrfProtection, async (req: Request, res: Response) => {
    try {
      const { name, description, price, billingPeriod, features, maxUsers, maxTransactions, stripePriceId } = req.body;

      const [newPlan] = await db.insert(schema.subscriptionPlans).values({
        name,
        description,
        price,
        billingPeriod,
        features: features || [],
        maxUsers,
        maxTransactions,
        stripePriceId,
      }).returning();

      // Log audit
      await db.insert(schema.auditLogs).values({
        userId: req.user!.id,
        organizationId: req.user!.organizationId,
        action: "create_subscription_plan",
        entityType: "subscription_plan",
        entityId: newPlan.id,
        newValue: JSON.stringify(newPlan),
        ipAddress: req.ip,
        userAgent: req.get('user-agent'),
      });

      res.json({ plan: newPlan, message: "Plano criado com sucesso" });
    } catch (error) {
      console.error("Error creating subscription plan:", error);
      res.status(500).json({ message: "Erro ao criar plano de assinatura" });
    }
  });

  // Update subscription plan (OWNER only)
  app.put("/api/subscription-plans/:id", isAuthenticated, isOwner, csrfProtection, async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const { name, description, price, billingPeriod, features, maxUsers, maxTransactions, isActive, stripePriceId } = req.body;

      // Get old plan for audit log
      const [oldPlan] = await db.select().from(schema.subscriptionPlans).where(eq(schema.subscriptionPlans.id, id));

      const [updatedPlan] = await db.update(schema.subscriptionPlans)
        .set({
          name,
          description,
          price,
          billingPeriod,
          features,
          maxUsers,
          maxTransactions,
          isActive,
          stripePriceId,
          updatedAt: new Date(),
        })
        .where(eq(schema.subscriptionPlans.id, id))
        .returning();

      // Log audit
      await db.insert(schema.auditLogs).values({
        userId: req.user!.id,
        organizationId: req.user!.organizationId,
        action: "update_subscription_plan",
        entityType: "subscription_plan",
        entityId: id,
        oldValue: JSON.stringify(oldPlan),
        newValue: JSON.stringify(updatedPlan),
        ipAddress: req.ip,
        userAgent: req.get('user-agent'),
      });

      res.json({ plan: updatedPlan, message: "Plano atualizado com sucesso" });
    } catch (error) {
      console.error("Error updating subscription plan:", error);
      res.status(500).json({ message: "Erro ao atualizar plano de assinatura" });
    }
  });

  // Delete subscription plan (OWNER only)
  app.delete("/api/subscription-plans/:id", isAuthenticated, isOwner, csrfProtection, async (req: Request, res: Response) => {
    try {
      const { id } = req.params;

      const [deletedPlan] = await db.delete(schema.subscriptionPlans)
        .where(eq(schema.subscriptionPlans.id, id))
        .returning();

      // Log audit
      await db.insert(schema.auditLogs).values({
        userId: req.user!.id,
        organizationId: req.user!.organizationId,
        action: "delete_subscription_plan",
        entityType: "subscription_plan",
        entityId: id,
        oldValue: JSON.stringify(deletedPlan),
        ipAddress: req.ip,
        userAgent: req.get('user-agent'),
      });

      res.json({ message: "Plano deletado com sucesso" });
    } catch (error) {
      console.error("Error deleting subscription plan:", error);
      res.status(500).json({ message: "Erro ao deletar plano de assinatura" });
    }
  });

  // AUDIT LOGS ROUTES (OWNER ONLY)
  // Get audit logs
  app.get("/api/audit-logs", isAuthenticated, isOwner, async (req: Request, res: Response) => {
    try {
      const { limit = 100, offset = 0 } = req.query;

      const logs = await db.select()
        .from(schema.auditLogs)
        .where(req.user!.organizationId ? eq(schema.auditLogs.organizationId, req.user!.organizationId) : undefined)
        .orderBy(desc(schema.auditLogs.createdAt))
        .limit(Number(limit))
        .offset(Number(offset));

      const total = await db.select({ count: sql<number>`count(*)` })
        .from(schema.auditLogs)
        .where(req.user!.organizationId ? eq(schema.auditLogs.organizationId, req.user!.organizationId) : undefined);

      res.json({ 
        logs, 
        total: total[0]?.count || 0,
        limit: Number(limit),
        offset: Number(offset),
      });
    } catch (error) {
      console.error("Error fetching audit logs:", error);
      res.status(500).json({ message: "Erro ao buscar logs de auditoria" });
    }
  });

  // ORGANIZATIONS ROUTES
  // Get current organization
  app.get("/api/organizations/current", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(404).json({ message: "No organization found" });
      }
      const organization = await storage.getOrganization(req.user!.organizationId);
      res.json(organization);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch organization" });
    }
  });

  // Update current organization
  app.put("/api/organizations/current", isAuthenticated, isAdminOrOwner, csrfProtection, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(404).json({ message: "No organization found" });
      }
      const organization = await storage.updateOrganization(req.user!.organizationId, req.body);
      res.json(organization);
    } catch (error) {
      res.status(500).json({ message: "Failed to update organization" });
    }
  });

  // Update organization
  app.put("/api/organizations/:id", isAuthenticated, isAdminOrOwner, async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      if (id !== req.user!.organizationId) {
        return res.status(403).json({ message: "Cannot update other organizations" });
      }
      const organization = await storage.updateOrganization(id, req.body);
      res.json(organization);
    } catch (error) {
      res.status(500).json({ message: "Failed to update organization" });
    }
  });

  // CUSTOMERS ROUTES
  // Get all customers for organization
  app.get("/api/customers", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const { page, limit, offset } = getPaginationParams(req.query.page as string, req.query.limit as string);
      const { data, total } = await storage.getCustomersByOrganizationPaginated(req.user!.organizationId, offset, limit);
      res.json(createPaginatedResponse(data, total, page, limit));
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch customers" });
    }
  });

  // Get single customer
  app.get("/api/customers/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const customer = await storage.getCustomer(req.params.id);
      if (!customer || customer.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Customer not found" });
      }
      res.json(customer);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch customer" });
    }
  });

  // Create customer
  app.post(
    "/api/customers",
    isAuthenticated,
    validateBody(createCustomerSchema),
    async (req: Request, res: Response) => {
      try {
        const customer = await storage.createCustomer({
          ...req.body,
          organizationId: req.user!.organizationId!,
        });

        await storage.createActivity({
          organizationId: req.user!.organizationId!,
          userId: req.user!.id,
          action: "customer_created",
          entityType: "customer",
          entityId: customer.id,
          details: JSON.stringify({ name: customer.name }),
        });

        res.status(201).json(customer);
      } catch (error) {
        res.status(500).json({ message: "Failed to create customer" });
      }
    }
  );

  // Update customer
  app.put("/api/customers/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getCustomer(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Customer not found" });
      }

      const customer = await storage.updateCustomer(req.params.id, req.body);

      await storage.createActivity({
        organizationId: req.user!.organizationId!,
        userId: req.user!.id,
        action: "customer_updated",
        entityType: "customer",
        entityId: req.params.id,
        details: JSON.stringify({ name: customer?.name }),
      });

      res.json(customer);
    } catch (error) {
      res.status(500).json({ message: "Failed to update customer" });
    }
  });

  // Delete customer
  app.delete("/api/customers/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getCustomer(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Customer not found" });
      }

      await storage.deleteCustomer(req.params.id);

      await storage.createActivity({
        organizationId: req.user!.organizationId!,
        userId: req.user!.id,
        action: "customer_deleted",
        entityType: "customer",
        entityId: req.params.id,
        details: JSON.stringify({ name: existing.name }),
      });

      res.json({ message: "Customer deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete customer" });
    }
  });

  // Validate CPF/CNPJ
  app.post("/api/validate/document", async (req: Request, res: Response) => {
    try {
      const { document, type } = req.body;
      
      if (!document) {
        return res.status(400).json({ valid: false, message: "Documento não fornecido" });
      }

      const personType = type === "CPF" ? "PF" : "PJ";
      const validation = validateDocument(document, personType);
      
      res.json(validation);
    } catch (error) {
      res.status(500).json({ valid: false, message: "Erro ao validar documento" });
    }
  });

  // INVOICES ROUTES
  // Send invoice by email
  app.post("/api/invoices/:id/send-email", isAuthenticated, csrfProtection, async (req: Request, res: Response) => {
    try {
      const invoice = await storage.getInvoice(req.params.id);
      if (!invoice || invoice.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Invoice not found" });
      }

      const customer = await storage.getCustomer(invoice.customerId);
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }

      const organization = await storage.getOrganization(invoice.organizationId);
      if (!organization) {
        return res.status(404).json({ message: "Organization not found" });
      }

      const { sendEmail, generateInvoiceEmail } = await import("./email");
      
      const emailHtml = generateInvoiceEmail({
        invoiceNumber: invoice.invoiceNumber,
        customerName: customer.name,
        customerEmail: customer.email,
        amount: invoice.amount,
        dueDate: invoice.dueDate ? new Date(invoice.dueDate).toLocaleDateString('pt-BR') : 'N/A',
        description: invoice.description || '',
        issueDate: new Date(invoice.issueDate).toLocaleDateString('pt-BR'),
        organizationName: organization.name,
      });

      const sent = await sendEmail({
        to: customer.email,
        subject: `Fatura ${invoice.invoiceNumber} - ${organization.name}`,
        html: emailHtml,
      });

      if (sent) {
        res.json({ message: "Invoice sent by email successfully" });
      } else {
        res.status(500).json({ message: "Failed to send invoice by email" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to send invoice by email" });
    }
  });

  // Get all invoices for organization
  app.get("/api/invoices", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const { page, limit, offset } = getPaginationParams(req.query.page as string, req.query.limit as string);
      const { data, total } = await storage.getInvoicesByOrganizationPaginated(req.user!.organizationId, offset, limit);
      res.json(createPaginatedResponse(data, total, page, limit));
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch invoices" });
    }
  });

  // Get invoices by customer
  app.get("/api/customers/:customerId/invoices", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const customer = await storage.getCustomer(req.params.customerId);
      if (!customer || customer.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Customer not found" });
      }
      const invoices = await storage.getInvoicesByCustomer(req.params.customerId);
      res.json(invoices);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch invoices" });
    }
  });

  // Get single invoice
  app.get("/api/invoices/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const invoice = await storage.getInvoice(req.params.id);
      if (!invoice || invoice.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Invoice not found" });
      }
      res.json(invoice);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch invoice" });
    }
  });

  // Create invoice
  app.post(
    "/api/invoices",
    isAuthenticated,
    validateBody(createInvoiceSchema),
    async (req: Request, res: Response) => {
      try {
        // Verify customer belongs to organization
        const customer = await storage.getCustomer(req.body.customerId);
        if (!customer || customer.organizationId !== req.user!.organizationId) {
          return res.status(400).json({ message: "Invalid customer" });
        }

        // Generate invoice number
        const timestamp = Date.now();
        const invoiceNumber = `INV-${timestamp}`;

        const invoice = await storage.createInvoice({
          ...req.body,
          organizationId: req.user!.organizationId!,
          invoiceNumber,
        });

        await storage.createActivity({
          organizationId: req.user!.organizationId!,
          userId: req.user!.id,
          action: "invoice_created",
          entityType: "invoice",
          entityId: invoice.id,
          details: JSON.stringify({ invoiceNumber, amount: invoice.amount }),
        });

        res.status(201).json(invoice);
      } catch (error) {
        res.status(500).json({ message: "Failed to create invoice" });
      }
    }
  );

  // Update invoice
  app.put("/api/invoices/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getInvoice(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Invoice not found" });
      }

      const invoice = await storage.updateInvoice(req.params.id, req.body);

      await storage.createActivity({
        organizationId: req.user!.organizationId!,
        userId: req.user!.id,
        action: "invoice_updated",
        entityType: "invoice",
        entityId: req.params.id,
        details: JSON.stringify({ invoiceNumber: invoice?.invoiceNumber }),
      });

      res.json(invoice);
    } catch (error) {
      res.status(500).json({ message: "Failed to update invoice" });
    }
  });

  // Delete invoice
  app.delete("/api/invoices/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getInvoice(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Invoice not found" });
      }

      await storage.deleteInvoice(req.params.id);

      await storage.createActivity({
        organizationId: req.user!.organizationId!,
        userId: req.user!.id,
        action: "invoice_deleted",
        entityType: "invoice",
        entityId: req.params.id,
        details: JSON.stringify({ invoiceNumber: existing.invoiceNumber }),
      });

      res.json({ message: "Invoice deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete invoice" });
    }
  });

  // METRICS ROUTES
  app.get("/api/metrics", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const metrics = await storage.getMetrics(req.user!.organizationId);
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch metrics" });
    }
  });

  // Monthly Revenue Data
  app.get("/api/metrics/monthly-revenue", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const data = await storage.getMonthlyRevenueData(req.user!.organizationId);
      res.json(data);
    } catch (error) {
      console.error("Failed to fetch monthly revenue:", error);
      res.status(500).json({ message: "Failed to fetch monthly revenue data" });
    }
  });

  // ACTIVITIES ROUTES
  app.get("/api/activities", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
      const activities = await storage.getActivitiesByOrganization(req.user!.organizationId, limit);
      res.json(activities);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch activities" });
    }
  });

  // CATEGORIES ROUTES
  app.get("/api/categories", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const categories = await storage.getCategoriesByOrganization(req.user!.organizationId);
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  app.post("/api/categories", isAuthenticated, validateBody(createCategorySchema), async (req: Request, res: Response) => {
    try {
      const category = await storage.createCategory({
        ...req.body,
        organizationId: req.user!.organizationId!,
      });
      res.status(201).json(category);
    } catch (error) {
      res.status(500).json({ message: "Failed to create category" });
    }
  });

  app.put("/api/categories/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getCategory(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Category not found" });
      }
      const category = await storage.updateCategory(req.params.id, req.body);
      res.json(category);
    } catch (error) {
      res.status(500).json({ message: "Failed to update category" });
    }
  });

  app.delete("/api/categories/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getCategory(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Category not found" });
      }
      await storage.deleteCategory(req.params.id);
      res.json({ message: "Category deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete category" });
    }
  });

  // BANK ACCOUNTS ROUTES
  app.get("/api/bank-accounts", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const accounts = await storage.getBankAccountsByOrganization(req.user!.organizationId);
      res.json(accounts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch bank accounts" });
    }
  });

  app.post("/api/bank-accounts", isAuthenticated, validateBody(createBankAccountSchema), async (req: Request, res: Response) => {
    try {
      const account = await storage.createBankAccount({
        ...req.body,
        organizationId: req.user!.organizationId!,
      });
      res.status(201).json(account);
    } catch (error) {
      res.status(500).json({ message: "Failed to create bank account" });
    }
  });

  app.put("/api/bank-accounts/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getBankAccount(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Bank account not found" });
      }
      const account = await storage.updateBankAccount(req.params.id, req.body);
      res.json(account);
    } catch (error) {
      res.status(500).json({ message: "Failed to update bank account" });
    }
  });

  app.delete("/api/bank-accounts/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getBankAccount(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Bank account not found" });
      }
      await storage.deleteBankAccount(req.params.id);
      res.json({ message: "Bank account deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete bank account" });
    }
  });

  // COST CENTERS ROUTES
  app.get("/api/cost-centers", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const centers = await storage.getCostCentersByOrganization(req.user!.organizationId);
      res.json(centers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch cost centers" });
    }
  });

  app.post("/api/cost-centers", isAuthenticated, validateBody(createCostCenterSchema), async (req: Request, res: Response) => {
    try {
      const center = await storage.createCostCenter({
        ...req.body,
        organizationId: req.user!.organizationId!,
      });
      res.status(201).json(center);
    } catch (error) {
      res.status(500).json({ message: "Failed to create cost center" });
    }
  });

  app.put("/api/cost-centers/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getCostCenter(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Cost center not found" });
      }
      const center = await storage.updateCostCenter(req.params.id, req.body);
      res.json(center);
    } catch (error) {
      res.status(500).json({ message: "Failed to update cost center" });
    }
  });

  app.delete("/api/cost-centers/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getCostCenter(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Cost center not found" });
      }
      await storage.deleteCostCenter(req.params.id);
      res.json({ message: "Cost center deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete cost center" });
    }
  });

  // TAGS ROUTES
  app.get("/api/tags", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const tags = await storage.getTagsByOrganization(req.user!.organizationId);
      res.json(tags);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch tags" });
    }
  });

  app.post("/api/tags", isAuthenticated, validateBody(createTagSchema), async (req: Request, res: Response) => {
    try {
      const tag = await storage.createTag({
        ...req.body,
        organizationId: req.user!.organizationId!,
      });
      res.status(201).json(tag);
    } catch (error) {
      res.status(500).json({ message: "Failed to create tag" });
    }
  });

  app.put("/api/tags/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getTag(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Tag not found" });
      }
      const tag = await storage.updateTag(req.params.id, req.body);
      res.json(tag);
    } catch (error) {
      res.status(500).json({ message: "Failed to update tag" });
    }
  });

  app.delete("/api/tags/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getTag(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Tag not found" });
      }
      await storage.deleteTag(req.params.id);
      res.json({ message: "Tag deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete tag" });
    }
  });

  // TRANSACTIONS ROUTES
  app.get("/api/transactions", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const { page, limit, offset } = getPaginationParams(req.query.page as string, req.query.limit as string);
      const { data, total } = await storage.getTransactionsByOrganizationPaginated(req.user!.organizationId, offset, limit);
      res.json(createPaginatedResponse(data, total, page, limit));
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  app.get("/api/transactions/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const transaction = await storage.getTransaction(req.params.id);
      if (!transaction || transaction.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Transaction not found" });
      }
      res.json(transaction);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch transaction" });
    }
  });

  app.post("/api/transactions", isAuthenticated, validateBody(createTransactionSchema), async (req: Request, res: Response) => {
    try {
      const transaction = await storage.createTransaction({
        ...req.body,
        organizationId: req.user!.organizationId!,
      });

      await storage.createActivity({
        organizationId: req.user!.organizationId!,
        userId: req.user!.id,
        action: "transaction_created",
        entityType: "transaction",
        entityId: transaction.id,
        details: JSON.stringify({ description: transaction.description, amount: transaction.amount }),
      });

      res.status(201).json(transaction);
    } catch (error) {
      res.status(500).json({ message: "Failed to create transaction" });
    }
  });

  app.put("/api/transactions/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getTransaction(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Transaction not found" });
      }
      const transaction = await storage.updateTransaction(req.params.id, req.body);
      res.json(transaction);
    } catch (error) {
      res.status(500).json({ message: "Failed to update transaction" });
    }
  });

  app.delete("/api/transactions/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getTransaction(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Transaction not found" });
      }
      await storage.deleteTransaction(req.params.id);
      res.json({ message: "Transaction deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete transaction" });
    }
  });

  // DOCUMENTS ROUTES
  app.get("/api/documents", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const documents = await storage.getDocumentsByOrganization(req.user!.organizationId);
      res.json(documents);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch documents" });
    }
  });

  app.post("/api/documents", isAuthenticated, validateBody(createDocumentSchema), async (req: Request, res: Response) => {
    try {
      const document = await storage.createDocument({
        ...req.body,
        organizationId: req.user!.organizationId!,
        uploadedBy: req.user!.id,
      });
      res.status(201).json(document);
    } catch (error) {
      res.status(500).json({ message: "Failed to create document" });
    }
  });

  app.delete("/api/documents/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getDocument(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Document not found" });
      }
      await storage.deleteDocument(req.params.id);
      res.json({ message: "Document deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete document" });
    }
  });

  // RECONCILIATIONS ROUTES
  app.get("/api/reconciliations", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const reconciliations = await storage.getReconciliationsByOrganization(req.user!.organizationId);
      res.json(reconciliations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch reconciliations" });
    }
  });

  app.post("/api/reconciliations", isAuthenticated, validateBody(createReconciliationSchema), async (req: Request, res: Response) => {
    try {
      const reconciliation = await storage.createReconciliation({
        ...req.body,
        organizationId: req.user!.organizationId!,
      });
      res.status(201).json(reconciliation);
    } catch (error) {
      res.status(500).json({ message: "Failed to create reconciliation" });
    }
  });

  app.delete("/api/reconciliations/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getReconciliation(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Reconciliation not found" });
      }
      await storage.deleteReconciliation(req.params.id);
      res.json({ message: "Reconciliation deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete reconciliation" });
    }
  });

  // NOTIFICATIONS ROUTES
  app.get("/api/notifications", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
      const notifications = await storage.getNotificationsByUser(req.user!.id, limit);
      res.json(notifications);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });

  app.get("/api/notifications/unread", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const notifications = await storage.getUnreadNotificationsByUser(req.user!.id);
      res.json(notifications);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch unread notifications" });
    }
  });

  app.put("/api/notifications/:id/read", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const notification = await storage.getNotification(req.params.id);
      if (!notification || notification.userId !== req.user!.id) {
        return res.status(404).json({ message: "Notification not found" });
      }
      const updated = await storage.markNotificationAsRead(req.params.id);
      res.json(updated);
    } catch (error) {
      res.status(500).json({ message: "Failed to mark notification as read" });
    }
  });

  app.put("/api/notifications/read-all", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const count = await storage.markAllNotificationsAsRead(req.user!.id);
      res.json({ message: `${count} notifications marked as read`, count });
    } catch (error) {
      res.status(500).json({ message: "Failed to mark all notifications as read" });
    }
  });

  app.delete("/api/notifications/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const notification = await storage.getNotification(req.params.id);
      if (!notification || notification.userId !== req.user!.id) {
        return res.status(404).json({ message: "Notification not found" });
      }
      await storage.deleteNotification(req.params.id);
      res.json({ message: "Notification deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete notification" });
    }
  });

  app.post("/api/notifications", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const notification = await storage.createNotification({
        ...req.body,
        organizationId: req.user!.organizationId,
      });
      res.status(201).json(notification);
    } catch (error) {
      res.status(500).json({ message: "Failed to create notification" });
    }
  });

  // RECURRING TRANSACTIONS ROUTES
  app.get("/api/recurring-transactions", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const transactions = await storage.getRecurringTransactionsByOrganization(req.user!.organizationId);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recurring transactions" });
    }
  });

  app.get("/api/recurring-transactions/active", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const transactions = await storage.getActiveRecurringTransactions(req.user!.organizationId);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch active recurring transactions" });
    }
  });

  app.get("/api/recurring-transactions/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const transaction = await storage.getRecurringTransaction(req.params.id);
      if (!transaction || transaction.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Recurring transaction not found" });
      }
      res.json(transaction);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recurring transaction" });
    }
  });

  app.post("/api/recurring-transactions", isAuthenticated, csrfProtection, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const transaction = await storage.createRecurringTransaction({
        ...req.body,
        organizationId: req.user!.organizationId,
      });
      res.status(201).json(transaction);
    } catch (error) {
      res.status(500).json({ message: "Failed to create recurring transaction" });
    }
  });

  app.put("/api/recurring-transactions/:id", isAuthenticated, csrfProtection, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getRecurringTransaction(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Recurring transaction not found" });
      }
      const transaction = await storage.updateRecurringTransaction(req.params.id, req.body);
      res.json(transaction);
    } catch (error) {
      res.status(500).json({ message: "Failed to update recurring transaction" });
    }
  });

  app.delete("/api/recurring-transactions/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getRecurringTransaction(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Recurring transaction not found" });
      }
      await storage.deleteRecurringTransaction(req.params.id);
      res.json({ message: "Recurring transaction deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete recurring transaction" });
    }
  });

  // USER PROFILE ROUTES
  app.put("/api/user/profile", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { name, email, avatar } = req.body;
      const user = await storage.updateUser(req.user!.id, { name, email, avatar });
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  app.put("/api/user/password", isAuthenticated, csrfProtection, async (req: Request, res: Response) => {
    try {
      const { currentPassword, newPassword } = req.body;
      const user = await storage.getUser(req.user!.id);
      
      if (!user || !await bcrypt.compare(currentPassword, user.password)) {
        return res.status(400).json({ message: "Senha atual incorreta" });
      }

      // Validate that new password is different from current password
      if (await bcrypt.compare(newPassword, user.password)) {
        return res.status(400).json({ message: "A nova senha não pode ser igual à senha atual" });
      }

      const hashedPassword = await bcrypt.hash(newPassword, 10);
      await storage.updateUser(req.user!.id, { 
        password: hashedPassword,
        passwordChangedAt: new Date()
      });
      
      // Logout user for security - destroy session
      req.logout((err) => {
        if (err) {
          console.error("Error logging out after password change:", err);
        }
      });
      
      req.session.destroy((err) => {
        if (err) {
          console.error("Error destroying session after password change:", err);
        }
      });
      
      res.json({ message: "Senha alterada com sucesso. Faça login novamente.", requiresReauth: true });
    } catch (error) {
      res.status(500).json({ message: "Falha ao atualizar senha" });
    }
  });

  // 2FA ROUTES
  app.post("/api/user/2fa/generate", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const user = await storage.getUser(req.user!.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const { secret, qrCodeUrl } = await generate2FASecret(user.email);
      
      await storage.updateUser(req.user!.id, { twoFactorSecret: secret });
      
      res.json({ qrCodeUrl, secret });
    } catch (error) {
      console.error("Failed to generate 2FA:", error);
      res.status(500).json({ message: "Failed to generate 2FA" });
    }
  });

  app.post("/api/user/2fa/verify", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { token } = req.body;
      const user = await storage.getUser(req.user!.id);
      
      if (!user || !user.twoFactorSecret) {
        return res.status(400).json({ message: "2FA not configured" });
      }

      const isValid = verify2FAToken(token, user.twoFactorSecret);
      
      if (!isValid) {
        return res.status(400).json({ message: "Invalid token" });
      }

      await storage.updateUser(req.user!.id, { twoFactorEnabled: true });
      
      res.json({ message: "2FA enabled successfully" });
    } catch (error) {
      console.error("Failed to verify 2FA:", error);
      res.status(500).json({ message: "Failed to verify 2FA" });
    }
  });

  app.post("/api/user/2fa/disable", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { token } = req.body;
      const user = await storage.getUser(req.user!.id);
      
      if (!user || !user.twoFactorSecret) {
        return res.status(400).json({ message: "2FA not configured" });
      }

      const isValid = verify2FAToken(token, user.twoFactorSecret);
      
      if (!isValid) {
        return res.status(400).json({ message: "Invalid token" });
      }

      await storage.updateUser(req.user!.id, { 
        twoFactorEnabled: false,
        twoFactorSecret: null
      });
      
      res.json({ message: "2FA disabled successfully" });
    } catch (error) {
      console.error("Failed to disable 2FA:", error);
      res.status(500).json({ message: "Failed to disable 2FA" });
    }
  });

  app.get("/api/user/2fa/status", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const user = await storage.getUser(req.user!.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      res.json({ 
        enabled: user.twoFactorEnabled || false,
        configured: !!user.twoFactorSecret
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to get 2FA status" });
    }
  });

  // SESSIONS ROUTES
  app.get("/api/user/sessions", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const sessionId = req.sessionID;
      const sessions = await getActiveSessions(req.user!.id, sessionId);
      res.json(sessions);
    } catch (error) {
      console.error("Failed to get sessions:", error);
      res.status(500).json({ message: "Failed to get sessions" });
    }
  });

  app.delete("/api/user/sessions/:sessionId", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { sessionId } = req.params;
      const success = await revokeSession(sessionId, req.user!.id);
      
      if (!success) {
        return res.status(400).json({ message: "Failed to revoke session" });
      }
      
      res.json({ message: "Session revoked successfully" });
    } catch (error) {
      console.error("Failed to revoke session:", error);
      res.status(500).json({ message: "Failed to revoke session" });
    }
  });

  // USER PREFERENCES ROUTES
  app.get("/api/user/preferences", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const user = await storage.getUser(req.user!.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      res.json({
        emailNotifications: user.emailNotifications ?? true,
        activityAlerts: user.activityAlerts ?? true,
        themePreference: user.themePreference || "system",
        colorScheme: user.colorScheme || "purple",
      });
    } catch (error) {
      console.error("Failed to get preferences:", error);
      res.status(500).json({ message: "Failed to get preferences" });
    }
  });

  app.put("/api/user/preferences", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { emailNotifications, activityAlerts, themePreference, colorScheme } = req.body;
      
      await storage.updateUser(req.user!.id, {
        emailNotifications,
        activityAlerts,
        themePreference,
        colorScheme,
      });
      
      const user = await storage.getUser(req.user!.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({
        emailNotifications: user.emailNotifications ?? true,
        activityAlerts: user.activityAlerts ?? true,
        themePreference: user.themePreference || "system",
        colorScheme: user.colorScheme || "purple",
      });
    } catch (error) {
      console.error("Failed to update preferences:", error);
      res.status(500).json({ message: "Failed to update preferences" });
    }
  });

  // REPORTS ROUTES
  app.get("/api/reports/dre", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      
      const startDate = req.query.startDate ? new Date(req.query.startDate as string) : undefined;
      const endDate = req.query.endDate ? new Date(req.query.endDate as string) : undefined;
      
      const report = await storage.getDREReport(req.user!.organizationId, startDate, endDate);
      res.json(report);
    } catch (error) {
      console.error("Failed to generate DRE report:", error);
      res.status(500).json({ message: "Failed to generate DRE report" });
    }
  });

  app.get("/api/reports/cash-flow", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      
      const startDate = req.query.startDate ? new Date(req.query.startDate as string) : undefined;
      const endDate = req.query.endDate ? new Date(req.query.endDate as string) : undefined;
      
      const report = await storage.getCashFlowReport(req.user!.organizationId, startDate, endDate);
      res.json(report);
    } catch (error) {
      console.error("Failed to generate cash flow report:", error);
      res.status(500).json({ message: "Failed to generate cash flow report" });
    }
  });

  app.get("/api/reports/statement", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      
      const startDate = req.query.startDate ? new Date(req.query.startDate as string) : undefined;
      const endDate = req.query.endDate ? new Date(req.query.endDate as string) : undefined;
      
      const report = await storage.getStatementReport(req.user!.organizationId, startDate, endDate);
      res.json(report);
    } catch (error) {
      console.error("Failed to generate statement report:", error);
      res.status(500).json({ message: "Failed to generate statement report" });
    }
  });

  // EXPORT ROUTES
  const handleTransactionsExport = async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }

      const format = (req.query.format as string) || "json";
      const transactions = await storage.getTransactionsByOrganization(req.user!.organizationId);
      
      const data = transactions.map(t => ({
        Data: t.date,
        Descrição: t.description,
        Tipo: t.type === 'income' ? 'Receita' : 'Despesa',
        Valor: parseFloat(t.amount),
        Pago: t.isPaid ? 'Sim' : 'Não',
        'Data Pagamento': t.paidDate || '',
        Observações: t.notes || ''
      }));

      if (format === "excel" || format === "xlsx") {
        const ws = XLSX.utils.json_to_sheet(data);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Transações");
        const buffer = XLSX.write(wb, { type: "buffer", bookType: "xlsx" });
        
        res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        res.setHeader("Content-Disposition", `attachment; filename=transacoes_${new Date().toISOString().split('T')[0]}.xlsx`);
        res.send(buffer);
      } else if (format === "csv") {
        const parser = new Parser();
        const csv = parser.parse(data);
        
        res.setHeader("Content-Type", "text/csv; charset=utf-8");
        res.setHeader("Content-Disposition", `attachment; filename=transacoes_${new Date().toISOString().split('T')[0]}.csv`);
        res.send(csv);
      } else {
        res.json(data);
      }
    } catch (error) {
      console.error("Failed to export transactions:", error);
      res.status(500).json({ message: "Failed to export transactions" });
    }
  };

  app.get("/api/export/transactions", isAuthenticated, handleTransactionsExport);
  app.get("/api/exports/transactions", isAuthenticated, handleTransactionsExport);

  app.get("/api/export/customers", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }

      const format = (req.query.format as string) || "json";
      const customers = await storage.getCustomersByOrganization(req.user!.organizationId);
      
      const data = customers.map(c => ({
        Nome: c.name,
        Email: c.email,
        Telefone: c.phone || '',
        Documento: c.document || '',
        Cidade: c.city || '',
        Estado: c.state || '',
        'Data Criação': c.createdAt
      }));

      if (format === "excel") {
        const ws = XLSX.utils.json_to_sheet(data);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Clientes");
        const buffer = XLSX.write(wb, { type: "buffer", bookType: "xlsx" });
        
        res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        res.setHeader("Content-Disposition", `attachment; filename=clientes_${new Date().toISOString().split('T')[0]}.xlsx`);
        res.send(buffer);
      } else if (format === "csv") {
        const parser = new Parser();
        const csv = parser.parse(data);
        
        res.setHeader("Content-Type", "text/csv; charset=utf-8");
        res.setHeader("Content-Disposition", `attachment; filename=clientes_${new Date().toISOString().split('T')[0]}.csv`);
        res.send(csv);
      } else {
        res.json(data);
      }
    } catch (error) {
      console.error("Failed to export customers:", error);
      res.status(500).json({ message: "Failed to export customers" });
    }
  });

  app.get("/api/export/invoices", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }

      const format = (req.query.format as string) || "json";
      const invoices = await storage.getInvoicesByOrganization(req.user!.organizationId);
      
      const data = invoices.map(i => ({
        'Número': i.invoiceNumber,
        Descrição: i.description || '',
        Valor: parseFloat(i.amount),
        Status: i.status,
        'Data Emissão': i.issueDate,
        Vencimento: i.dueDate || '',
        'Data Pagamento': i.paidDate || ''
      }));

      if (format === "excel") {
        const ws = XLSX.utils.json_to_sheet(data);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Faturas");
        const buffer = XLSX.write(wb, { type: "buffer", bookType: "xlsx" });
        
        res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        res.setHeader("Content-Disposition", `attachment; filename=faturas_${new Date().toISOString().split('T')[0]}.xlsx`);
        res.send(buffer);
      } else if (format === "csv") {
        const parser = new Parser();
        const csv = parser.parse(data);
        
        res.setHeader("Content-Type", "text/csv; charset=utf-8");
        res.setHeader("Content-Disposition", `attachment; filename=faturas_${new Date().toISOString().split('T')[0]}.csv`);
        res.send(csv);
      } else {
        res.json(data);
      }
    } catch (error) {
      console.error("Failed to export invoices:", error);
      res.status(500).json({ message: "Failed to export invoices" });
    }
  });

  // ERROR LOGGING ENDPOINT (No CSRF protection - errors can happen before token is available)
  app.post("/api/errors/log", async (req: Request, res: Response) => {
    try {
      const errorData = req.body;
      console.error("Client Error:", {
        message: errorData.message,
        url: errorData.url,
        timestamp: errorData.timestamp,
        stack: errorData.stack,
      });
      res.json({ success: true });
    } catch (error) {
      console.error("Failed to log error:", error);
      res.status(500).json({ message: "Failed to log error" });
    }
  });

  // PASSWORD RESET ROUTES
  app.post("/api/auth/forgot-password", async (req: Request, res: Response) => {
    try {
      const { email } = req.body;
      
      if (!email) {
        return res.status(400).json({ message: "Email é obrigatório" });
      }

      const user = await storage.getUserByEmail(email);
      
      if (!user) {
        return res.json({ message: "Se o email existir, você receberá instruções de redefinição" });
      }

      const resetToken = crypto.randomUUID();
      const resetTokenExpiry = new Date(Date.now() + 60 * 60 * 1000);

      await storage.setPasswordResetToken(user.id, resetToken, resetTokenExpiry);

      const resetLink = `${process.env.APP_URL || req.protocol + '://' + req.get('host')}/reset-password?token=${resetToken}`;
      
      const { sendEmail, generatePasswordResetEmail } = await import("./email");
      await sendEmail({
        to: user.email,
        subject: "Redefinir Senha - LUCREI",
        html: generatePasswordResetEmail(resetLink, user.username),
      });

      res.json({ message: "Se o email existir, você receberá instruções de redefinição" });
    } catch (error) {
      console.error("Failed to process forgot password:", error);
      res.status(500).json({ message: "Erro ao processar solicitação" });
    }
  });

  app.post("/api/auth/reset-password", async (req: Request, res: Response) => {
    try {
      const { token, password } = req.body;
      
      if (!token || !password) {
        return res.status(400).json({ message: "Token e senha são obrigatórios" });
      }

      if (password.length < 8) {
        return res.status(400).json({ message: "Senha deve ter no mínimo 8 caracteres" });
      }

      const user = await storage.getUserByResetToken(token);
      
      if (!user || !user.resetTokenExpiry || user.resetTokenExpiry < new Date()) {
        return res.status(400).json({ message: "Token inválido ou expirado" });
      }

      const hashedPassword = await bcrypt.hash(password, 10);
      await storage.updateUserPassword(user.id, hashedPassword);
      await storage.clearPasswordResetToken(user.id);

      res.json({ message: "Senha redefinida com sucesso" });
    } catch (error) {
      console.error("Failed to reset password:", error);
      res.status(500).json({ message: "Erro ao redefinir senha" });
    }
  });

  // EMAIL VERIFICATION ROUTES
  app.post("/api/auth/verify-email", async (req: Request, res: Response) => {
    try {
      const { token } = req.body;
      
      if (!token) {
        return res.status(400).json({ message: "Token é obrigatório" });
      }

      const user = await storage.getUserByVerificationToken(token);
      
      if (!user) {
        return res.status(400).json({ message: "Token inválido" });
      }

      await storage.verifyUserEmail(user.id);

      const { sendEmail, generateWelcomeEmail } = await import("./email");
      await sendEmail({
        to: user.email,
        subject: "Bem-vindo ao LUCREI!",
        html: generateWelcomeEmail(user.username),
      });

      res.json({ message: "Email verificado com sucesso" });
    } catch (error) {
      console.error("Failed to verify email:", error);
      res.status(500).json({ message: "Erro ao verificar email" });
    }
  });

  app.post("/api/auth/resend-verification", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const user = await storage.getUserById(req.user!.id);
      
      if (!user) {
        return res.status(404).json({ message: "Usuário não encontrado" });
      }

      if (user.emailVerified) {
        return res.status(400).json({ message: "Email já verificado" });
      }

      const verificationToken = crypto.randomUUID();
      await storage.setEmailVerificationToken(user.id, verificationToken);

      const verifyLink = `${process.env.APP_URL || req.protocol + '://' + req.get('host')}/verify-email?token=${verificationToken}`;
      
      const { sendEmail, generateEmailVerificationEmail } = await import("./email");
      await sendEmail({
        to: user.email,
        subject: "Verificar Email - LUCREI",
        html: generateEmailVerificationEmail(verifyLink, user.username),
      });

      res.json({ message: "Email de verificação enviado" });
    } catch (error) {
      console.error("Failed to resend verification:", error);
      res.status(500).json({ message: "Erro ao enviar email de verificação" });
    }
  });

  // BULK OPERATIONS
  app.post("/api/transactions/bulk", isAuthenticated, csrfProtection, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }

      const { transactions } = req.body;

      if (!Array.isArray(transactions) || transactions.length === 0) {
        return res.status(400).json({ message: "Transactions array is required" });
      }

      if (transactions.length > 1000) {
        return res.status(400).json({ message: "Maximum 1000 transactions per bulk operation" });
      }

      const schema = z.array(createTransactionSchema);
      const validatedData = schema.parse(transactions);

      const createdTransactions = [];
      for (const transactionData of validatedData) {
        const transaction = await storage.createTransaction({
          ...transactionData,
          organizationId: req.user!.organizationId,
        });
        createdTransactions.push(transaction);
      }

      res.json({
        message: `${createdTransactions.length} transactions created successfully`,
        transactions: createdTransactions
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      console.error("Failed to create bulk transactions:", error);
      res.status(500).json({ message: "Failed to create bulk transactions" });
    }
  });

  // CSV IMPORT ROUTE
  const handleCSVImport = async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }

      const { csvData } = req.body;

      if (!csvData || typeof csvData !== 'string') {
        return res.status(400).json({ message: "CSV data is required" });
      }

      const { parseTransactionsCSV } = await import("./csv-import");
      const result = await parseTransactionsCSV(csvData);

      if (!result.success) {
        return res.status(400).json({
          message: "CSV validation failed",
          errors: result.errors,
          parsedCount: result.transactions.length,
        });
      }

      if (result.transactions.length > 1000) {
        return res.status(400).json({ message: "Maximum 1000 transactions per import" });
      }

      const createdTransactions = [];
      for (const transactionData of result.transactions) {
        const transaction = await storage.createTransaction({
          organizationId: req.user!.organizationId,
          date: transactionData.date,
          description: transactionData.description,
          amount: transactionData.amount.toString(),
          type: transactionData.type,
          notes: transactionData.notes || null,
          isPaid: transactionData.type === 'income',
        });
        createdTransactions.push(transaction);
      }

      res.json({
        message: `${createdTransactions.length} transactions imported successfully`,
        transactions: createdTransactions,
        errors: result.errors,
      });
    } catch (error) {
      console.error("Failed to import CSV:", error);
      res.status(500).json({ message: error instanceof Error ? error.message : "Failed to import CSV" });
    }
  };

  app.post("/api/transactions/import/csv", isAuthenticated, csrfProtection, handleCSVImport);
  app.post("/api/transactions/import-csv", isAuthenticated, csrfProtection, handleCSVImport);

  // GET CSV Template
  app.get("/api/transactions/import/csv/template", isAuthenticated, (req: Request, res: Response) => {
    try {
      const { generateCSVTemplate } = require("./csv-import");
      const template = generateCSVTemplate();
      
      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", "attachment; filename=template_transacoes.csv");
      res.send(template);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate CSV template" });
    }
  });

  // STRIPE ROUTES
  // Get current subscription
  app.get("/api/subscription", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }

      const subscriptions = await storage.getSubscriptionsByOrganization(req.user!.organizationId);
      
      if (subscriptions.length === 0) {
        return res.status(404).json({ message: "No subscription found" });
      }

      const activeSubscription = subscriptions.find((sub: Subscription) => sub.status === "active" || sub.status === "trialing");
      
      if (!activeSubscription) {
        return res.status(404).json({ message: "No active subscription" });
      }

      res.json(activeSubscription);
    } catch (error) {
      console.error("Failed to fetch subscription:", error);
      res.status(500).json({ message: "Failed to fetch subscription" });
    }
  });

  app.post("/api/stripe/create-checkout-session", isAuthenticated, csrfProtection, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }

      const { priceId } = req.body;
      
      if (!priceId) {
        return res.status(400).json({ message: "Price ID is required" });
      }

      const org = await storage.getOrganization(req.user!.organizationId);
      
      const { createCheckoutSession } = await import("./stripe");
      const successUrl = `${req.protocol}://${req.get('host')}/app/subscription?success=true`;
      const cancelUrl = `${req.protocol}://${req.get('host')}/app/subscription?canceled=true`;
      
      const session = await createCheckoutSession(
        org?.stripeCustomerId || null,
        priceId,
        req.user!.organizationId,
        successUrl,
        cancelUrl
      );

      res.json({ sessionId: session.id, url: session.url });
    } catch (error) {
      console.error("Failed to create checkout session:", error);
      res.status(500).json({ message: "Failed to create checkout session" });
    }
  });

  app.post("/api/stripe/create-portal-session", isAuthenticated, csrfProtection, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }

      const org = await storage.getOrganization(req.user!.organizationId);
      
      if (!org?.stripeCustomerId) {
        return res.status(400).json({ message: "No Stripe customer ID" });
      }

      const { createBillingPortalSession } = await import("./stripe");
      const returnUrl = `${req.protocol}://${req.get('host')}/app/subscription`;
      
      const session = await createBillingPortalSession(org.stripeCustomerId, returnUrl);

      res.json({ url: session.url });
    } catch (error) {
      console.error("Failed to create portal session:", error);
      res.status(500).json({ message: "Failed to create portal session" });
    }
  });

  app.post("/api/stripe/webhook", express.raw({ type: "application/json" }), async (req: Request, res: Response) => {
    try {
      const signature = req.headers["stripe-signature"];
      
      if (!signature || Array.isArray(signature)) {
        return res.status(400).json({ message: "Invalid signature" });
      }

      const { constructWebhookEvent, handleCheckoutSessionCompleted, handleSubscriptionUpdated, handleSubscriptionDeleted, handleInvoicePaymentSucceeded, handleInvoicePaymentFailed } = await import("./stripe");
      
      const event = await constructWebhookEvent(req.rawBody as Buffer, signature);

      switch (event.type) {
        case "checkout.session.completed":
          await handleCheckoutSessionCompleted(event.data.object as any, storage);
          break;
        case "customer.subscription.updated":
          await handleSubscriptionUpdated(event.data.object as any, storage);
          break;
        case "customer.subscription.deleted":
          await handleSubscriptionDeleted(event.data.object as any, storage);
          break;
        case "invoice.payment_succeeded":
          await handleInvoicePaymentSucceeded(event.data.object as any, storage);
          break;
        case "invoice.payment_failed":
          await handleInvoicePaymentFailed(event.data.object as any, storage);
          break;
      }

      res.json({ received: true });
    } catch (error) {
      console.error("Webhook error:", error);
      res.status(400).json({ message: "Webhook error" });
    }
  });

  // OFX ROUTES
  const handleOFXUpload = async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }

      const { fileContent, fileName, bankAccountId } = req.body;

      if (!fileContent) {
        return res.status(400).json({ message: "File content is required" });
      }

      if (!bankAccountId) {
        return res.status(400).json({ message: "Bank account ID is required" });
      }

      const { parseOFX } = await import("./ofx-parser");
      const ofxData = await parseOFX(fileContent);

      const reconciliation = await storage.createReconciliation({
        organizationId: req.user!.organizationId,
        bankAccountId,
        fileName: fileName || "upload.ofx",
        data: JSON.stringify(ofxData),
        status: "pending",
        startDate: ofxData.startDate,
        endDate: ofxData.endDate,
      });

      res.json({
        reconciliation,
        transactions: ofxData.transactions,
        summary: {
          total: ofxData.transactions.length,
          credits: ofxData.transactions.filter(t => t.type === "CREDIT").length,
          debits: ofxData.transactions.filter(t => t.type === "DEBIT").length,
          balance: ofxData.balance,
        }
      });
    } catch (error) {
      console.error("Failed to parse OFX:", error);
      res.status(500).json({ message: "Failed to parse OFX file" });
    }
  };

  app.post("/api/reconciliations/upload", isAuthenticated, csrfProtection, handleOFXUpload);
  app.post("/api/reconciliations/ofx", isAuthenticated, csrfProtection, handleOFXUpload);

  // PDF EXPORT ROUTES
  app.get("/api/reports/dre/pdf", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }

      const dreData = await storage.getDREReport(req.user!.organizationId);
      const { generateDREPDF } = await import("./pdf-generator");
      const pdfBuffer = await generateDREPDF(dreData);

      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `attachment; filename=dre_${new Date().toISOString().split('T')[0]}.pdf`);
      res.send(pdfBuffer);
    } catch (error) {
      console.error("Failed to generate DRE PDF:", error);
      res.status(500).json({ message: "Failed to generate PDF" });
    }
  });

  app.get("/api/reports/cash-flow/pdf", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }

      const cashFlowData = await storage.getCashFlowReport(req.user!.organizationId);
      const { generateCashFlowPDF } = await import("./pdf-generator");
      const pdfBuffer = await generateCashFlowPDF(cashFlowData);

      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `attachment; filename=fluxo_caixa_${new Date().toISOString().split('T')[0]}.pdf`);
      res.send(pdfBuffer);
    } catch (error) {
      console.error("Failed to generate Cash Flow PDF:", error);
      res.status(500).json({ message: "Failed to generate PDF" });
    }
  });

  app.get("/api/reports/statement/pdf", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }

      const startDate = req.query.startDate ? new Date(req.query.startDate as string) : undefined;
      const endDate = req.query.endDate ? new Date(req.query.endDate as string) : undefined;

      const statementData = await storage.getStatementReport(req.user!.organizationId, startDate, endDate);
      const { generateStatementPDF } = await import("./pdf-generator");
      const pdfBuffer = await generateStatementPDF(statementData);

      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `attachment; filename=extrato_${new Date().toISOString().split('T')[0]}.pdf`);
      res.send(pdfBuffer);
    } catch (error) {
      console.error("Failed to generate Statement PDF:", error);
      res.status(500).json({ message: "Failed to generate PDF" });
    }
  });

  app.get("/api/invoices/:id/pdf", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const invoice = await storage.getInvoice(req.params.id);
      
      if (!invoice || invoice.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Invoice not found" });
      }

      const { generateInvoicePDF } = await import("./pdf-generator");
      const pdfBuffer = await generateInvoicePDF(invoice);

      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `attachment; filename=fatura_${invoice.invoiceNumber}.pdf`);
      res.send(pdfBuffer);
    } catch (error) {
      console.error("Failed to generate Invoice PDF:", error);
      res.status(500).json({ message: "Failed to generate PDF" });
    }
  });

  // FILE UPLOAD ROUTES
  app.post("/api/documents/upload", isAuthenticated, csrfProtection, async (req: Request, res: Response) => {
    const { upload } = await import("./upload");
    
    upload.array("files", 5)(req, res, async (err) => {
      try {
        if (err) {
          if (err.message.includes("File too large")) {
            return res.status(413).json({ message: "File size exceeds 10MB limit" });
          }
          if (err.message.includes("not allowed")) {
            return res.status(415).json({ message: err.message });
          }
          return res.status(400).json({ message: "Upload failed" });
        }

        if (!req.user!.organizationId) {
          return res.status(400).json({ message: "No organization" });
        }

        const files = req.files as Express.Multer.File[];
        
        if (!files || files.length === 0) {
          return res.status(400).json({ message: "No files uploaded" });
        }

        const { getFileUrl } = await import("./upload");
        const uploadedDocs = [];

        for (const file of files) {
          const document = await storage.createDocument({
            organizationId: req.user!.organizationId,
            name: file.originalname,
            fileName: file.originalname,
            url: getFileUrl(file.filename),
            fileSize: file.size,
            mimeType: file.mimetype,
            entityType: req.body.entityType || null,
            entityId: req.body.entityId || null,
            uploadedBy: req.user!.id,
          });
          uploadedDocs.push(document);
        }

        res.json({
          message: `${uploadedDocs.length} file(s) uploaded successfully`,
          documents: uploadedDocs,
        });
      } catch (error) {
        console.error("Failed to upload documents:", error);
        res.status(500).json({ message: "Failed to upload documents" });
      }
    });
  });

  // Serve uploaded files
  app.use("/uploads", isAuthenticated, express.static("uploads"));

  // ========================
  // ADMIN ROUTES (ADMIN & OWNER)
  // ========================
  const adminRoutes = (await import("./admin-routes")).default;
  app.use("/api/admin", isAuthenticated, adminRoutes);

  // ========================
  // OWNER ROUTES (OWNER only)
  // ========================
  const ownerRoutes = (await import("./owner-routes")).default;
  app.use("/api/owner", isAuthenticated, ownerRoutes);

  // ========================
  // CMS ROUTES (Content Management System)
  // Public pages + Admin/Owner editing
  // ========================
  const cmsRoutes = (await import("./cms-routes")).default;
  app.use("/api/cms", cmsRoutes);

  // HEALTH CHECK ROUTES (should be before authentication)
  // These are used by load balancers, monitoring services, and Kubernetes
  app.get("/api/health", healthCheck);
  app.get("/api/liveness", liveness);
  app.get("/api/readiness", readiness);

  // METRICS ENDPOINT (Prometheus format)
  app.get("/metrics", async (req: Request, res: Response) => {
    try {
      res.set('Content-Type', metricsRegister.contentType);
      const metrics = await metricsRegister.metrics();
      res.end(metrics);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve metrics" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
