import Stripe from "stripe";

let stripeInstance: Stripe | null = null;

export function getStripe(): Stripe {
  if (!stripeInstance) {
    const apiKey = process.env.STRIPE_SECRET_KEY;
    if (!apiKey) {
      throw new Error("STRIPE_SECRET_KEY is not configured");
    }
    // Using account default API version for maximum compatibility
    stripeInstance = new Stripe(apiKey);
  }
  return stripeInstance;
}

export interface PriceConfig {
  starter: {
    monthly: string;
    yearly: string;
  };
  business: {
    monthly: string;
    yearly: string;
  };
  enterprise: {
    monthly: string;
    yearly: string;
  };
}

export const PRICES: PriceConfig = {
  starter: {
    monthly: process.env.STRIPE_PRICE_STARTER_MONTHLY || "",
    yearly: process.env.STRIPE_PRICE_STARTER_YEARLY || "",
  },
  business: {
    monthly: process.env.STRIPE_PRICE_BUSINESS_MONTHLY || "",
    yearly: process.env.STRIPE_PRICE_BUSINESS_YEARLY || "",
  },
  enterprise: {
    monthly: "",
    yearly: "",
  },
};

export async function createCheckoutSession(
  customerId: string | null,
  priceId: string,
  organizationId: string,
  successUrl: string,
  cancelUrl: string
): Promise<Stripe.Checkout.Session> {
  const stripe = getStripe();

  const session = await stripe.checkout.sessions.create({
    customer: customerId || undefined,
    mode: "subscription",
    payment_method_types: ["card"],
    line_items: [
      {
        price: priceId,
        quantity: 1,
      },
    ],
    success_url: successUrl,
    cancel_url: cancelUrl,
    metadata: {
      organizationId,
    },
    subscription_data: {
      trial_period_days: 7,
    },
  });

  return session;
}

export async function createBillingPortalSession(
  customerId: string,
  returnUrl: string
): Promise<Stripe.BillingPortal.Session> {
  const stripe = getStripe();

  const session = await stripe.billingPortal.sessions.create({
    customer: customerId,
    return_url: returnUrl,
  });

  return session;
}

export async function constructWebhookEvent(
  rawBody: Buffer,
  signature: string
): Promise<Stripe.Event> {
  const stripe = getStripe();
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

  if (!webhookSecret) {
    throw new Error("STRIPE_WEBHOOK_SECRET is not configured");
  }

  return stripe.webhooks.constructEvent(rawBody, signature, webhookSecret);
}

export async function handleCheckoutSessionCompleted(
  session: Stripe.Checkout.Session,
  storage: any
): Promise<void> {
  const organizationId = session.metadata?.organizationId;
  if (!organizationId) {
    console.error("No organizationId in session metadata");
    return;
  }

  const subscription = session.subscription as string;
  const customerId = session.customer as string;

  const stripeSubscription = await getStripe().subscriptions.retrieve(
    subscription
  );

  const planType =
    stripeSubscription.items.data[0].price.lookup_key?.split("_")[0] ||
    "starter";

  await storage.createSubscription({
    organizationId,
    stripeSubscriptionId: subscription,
    stripeCustomerId: customerId,
    stripePriceId: stripeSubscription.items.data[0].price.id,
    status: stripeSubscription.status,
    currentPeriodStart: new Date((stripeSubscription as any).current_period_start * 1000),
    currentPeriodEnd: new Date((stripeSubscription as any).current_period_end * 1000),
    planType: planType as "starter" | "business" | "enterprise",
    amount: (stripeSubscription.items.data[0].price.unit_amount! / 100).toString(),
  });

  await storage.updateOrganization(organizationId, {
    stripeCustomerId: customerId,
    planType: planType as "starter" | "business" | "enterprise",
  });
}

export async function handleSubscriptionUpdated(
  subscription: Stripe.Subscription,
  storage: any
): Promise<void> {
  const existing = await storage.getSubscriptionByStripeId(subscription.id);

  if (!existing) {
    console.error("Subscription not found:", subscription.id);
    return;
  }

  await storage.updateSubscription(existing.id, {
    status: subscription.status,
    currentPeriodStart: new Date((subscription as any).current_period_start * 1000),
    currentPeriodEnd: new Date((subscription as any).current_period_end * 1000),
    cancelAtPeriodEnd: subscription.cancel_at_period_end,
  });
}

export async function handleSubscriptionDeleted(
  subscription: Stripe.Subscription,
  storage: any
): Promise<void> {
  const existing = await storage.getSubscriptionByStripeId(subscription.id);

  if (!existing) {
    console.error("Subscription not found:", subscription.id);
    return;
  }

  await storage.updateSubscription(existing.id, {
    status: "canceled",
  });

  await storage.updateOrganization(existing.organizationId, {
    planType: "starter",
  });
  
  // Block users from this organization (set email_verified to false)
  await storage.blockOrganizationUsers(existing.organizationId);
}

export async function handleInvoicePaymentSucceeded(
  invoice: Stripe.Invoice,
  storage: any
): Promise<void> {
  const subscriptionId = invoice.subscription as string;
  
  if (!subscriptionId) {
    console.error("No subscription in invoice");
    return;
  }

  const existing = await storage.getSubscriptionByStripeId(subscriptionId);
  
  if (!existing) {
    console.error("Subscription not found:", subscriptionId);
    return;
  }

  // Reactivate organization and users
  await storage.updateSubscription(existing.id, {
    status: "active",
  });
  
  await storage.activateOrganizationUsers(existing.organizationId);
  
  // Record payment
  await storage.createPaymentHistory({
    organizationId: existing.organizationId,
    subscriptionId: existing.id,
    stripePaymentId: invoice.payment_intent as string,
    stripeInvoiceId: invoice.id,
    amount: (invoice.amount_paid / 100).toString(),
    currency: invoice.currency?.toUpperCase() || "BRL",
    status: "succeeded",
    paymentMethod: invoice.charge ? "card" : "unknown",
    paidAt: new Date(invoice.status_transitions.paid_at! * 1000),
  });
}

export async function handleInvoicePaymentFailed(
  invoice: Stripe.Invoice,
  storage: any
): Promise<void> {
  const subscriptionId = invoice.subscription as string;
  
  if (!subscriptionId) {
    console.error("No subscription in invoice");
    return;
  }

  const existing = await storage.getSubscriptionByStripeId(subscriptionId);
  
  if (!existing) {
    console.error("Subscription not found:", subscriptionId);
    return;
  }

  // Update subscription status to past_due
  await storage.updateSubscription(existing.id, {
    status: "past_due",
  });
  
  // Block organization users after failed payment
  await storage.blockOrganizationUsers(existing.organizationId);
  
  // Record failed payment
  await storage.createPaymentHistory({
    organizationId: existing.organizationId,
    subscriptionId: existing.id,
    stripePaymentId: invoice.payment_intent as string,
    stripeInvoiceId: invoice.id,
    amount: (invoice.amount_due / 100).toString(),
    currency: invoice.currency?.toUpperCase() || "BRL",
    status: "failed",
    failureReason: invoice.last_finalization_error?.message || "Payment failed",
    paidAt: null,
  });
}
