import { DbStorage } from "./storage";
import { logger } from "./logger";

export class RecurringTransactionsCron {
  private storage: DbStorage;
  private intervalId: NodeJS.Timeout | null = null;

  constructor(storage: DbStorage) {
    this.storage = storage;
  }

  start() {
    // Run every day at midnight
    const runDaily = () => {
      const now = new Date();
      const midnight = new Date(now);
      midnight.setHours(24, 0, 0, 0);
      const msUntilMidnight = midnight.getTime() - now.getTime();

      setTimeout(() => {
        this.processRecurringTransactions();
        // Schedule for next day
        this.intervalId = setInterval(() => {
          this.processRecurringTransactions();
        }, 24 * 60 * 60 * 1000);
      }, msUntilMidnight);
    };

    runDaily();
    logger.info("Recurring transactions cron job started");
  }

  stop() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
      logger.info("Recurring transactions cron job stopped");
    }
  }

  async processRecurringTransactions() {
    try {
      logger.info("Processing recurring transactions...");
      
      // Get all organizations
      const organizations = await this.storage.getAllOrganizations();
      
      for (const org of organizations) {
        const activeRecurring = await this.storage.getActiveRecurringTransactions(org.id);
        
        for (const recurring of activeRecurring) {
          try {
            await this.processRecurring(recurring, org.id);
          } catch (error) {
            logger.error(`Failed to process recurring transaction ${recurring.id}`, error);
          }
        }
      }
      
      logger.info("Recurring transactions processed successfully");
    } catch (error) {
      logger.error("Failed to process recurring transactions", error);
    }
  }

  private async processRecurring(recurring: any, organizationId: string) {
    const now = new Date();
    const startDate = new Date(recurring.startDate);
    
    // Check if we should start generating
    if (now < startDate) {
      return;
    }
    
    // Check if ended
    if (recurring.endDate && now > new Date(recurring.endDate)) {
      // Deactivate
      await this.storage.updateRecurringTransaction(recurring.id, { isActive: false });
      return;
    }
    
    // Check if we need to generate
    const lastGenerated = recurring.lastGeneratedDate ? new Date(recurring.lastGeneratedDate) : null;
    const shouldGenerate = this.shouldGenerateTransaction(now, lastGenerated, recurring.frequency, startDate);
    
    if (shouldGenerate) {
      // Calculate the transaction date
      const transactionDate = this.calculateNextTransactionDate(lastGenerated || startDate, recurring.frequency);
      
      // Create the transaction
      await this.storage.createTransaction({
        organizationId,
        description: recurring.description,
        amount: recurring.amount,
        type: recurring.type,
        categoryId: recurring.categoryId,
        bankAccountId: recurring.bankAccountId,
        costCenterId: recurring.costCenterId,
        date: transactionDate,
        isPaid: false,
        isRecurring: true,
        notes: recurring.notes ? `${recurring.notes} (Auto-generated from recurring transaction)` : "Auto-generated from recurring transaction",
      });
      
      // Update lastGeneratedDate using direct DB update
      await this.storage.updateRecurringTransaction(recurring.id, {
        lastGeneratedDate: transactionDate,
      } as any);
      
      logger.info(`Generated transaction for recurring ${recurring.id}`);
    }
  }

  private shouldGenerateTransaction(
    now: Date,
    lastGenerated: Date | null,
    frequency: string,
    startDate: Date
  ): boolean {
    if (!lastGenerated) {
      // Never generated, check if we should generate first one
      return now >= startDate;
    }
    
    const daysSinceLastGenerated = Math.floor((now.getTime() - lastGenerated.getTime()) / (1000 * 60 * 60 * 24));
    
    switch (frequency) {
      case 'daily':
        return daysSinceLastGenerated >= 1;
      case 'weekly':
        return daysSinceLastGenerated >= 7;
      case 'monthly':
        return daysSinceLastGenerated >= 30;
      case 'yearly':
        return daysSinceLastGenerated >= 365;
      default:
        return false;
    }
  }

  private calculateNextTransactionDate(lastDate: Date, frequency: string): Date {
    const nextDate = new Date(lastDate);
    
    switch (frequency) {
      case 'daily':
        nextDate.setDate(nextDate.getDate() + 1);
        break;
      case 'weekly':
        nextDate.setDate(nextDate.getDate() + 7);
        break;
      case 'monthly':
        nextDate.setMonth(nextDate.getMonth() + 1);
        break;
      case 'yearly':
        nextDate.setFullYear(nextDate.getFullYear() + 1);
        break;
    }
    
    return nextDate;
  }
}
