import { useState } from "react";
import { Button } from "@/components/ui/button";
import { X, AlertCircle } from "lucide-react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";

interface TrialBannerProps {
  daysLeft: number;
  isTrialing: boolean;
  hasActiveSubscription: boolean;
}

export default function TrialBanner({ daysLeft, isTrialing, hasActiveSubscription }: TrialBannerProps) {
  const [dismissed, setDismissed] = useState(false);
  const [, setLocation] = useLocation();

  if (dismissed || hasActiveSubscription || (!isTrialing && daysLeft <= 0)) {
    return null;
  }

  const showWarning = daysLeft <= 3;
  const bgColor = showWarning 
    ? "bg-gradient-to-r from-orange-600 to-red-600" 
    : "bg-gradient-to-r from-blue-600 via-blue-700 to-blue-800";

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -50 }}
        transition={{ duration: 0.3 }}
        className={`${bgColor} text-white relative`}
      >
        <div className="container mx-auto px-4 py-3">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-center sm:text-left">
              {showWarning && <AlertCircle className="h-5 w-5 flex-shrink-0 hidden sm:block" />}
              <span className="text-sm sm:text-base font-medium">
                {isTrialing ? (
                  <>
                    ⭐ Seu período de avaliação termina em <strong className="font-bold">{daysLeft} {daysLeft === 1 ? 'dia' : 'dias'}</strong>
                  </>
                ) : (
                  <>
                    ⚠️ Seu trial expirou! Assine agora para continuar usando.
                  </>
                )}
              </span>
            </div>
            
            <div className="flex items-center gap-2 flex-wrap justify-center">
              <Button 
                variant="secondary"
                size="sm"
                onClick={() => setLocation("/app/subscription")}
                className="bg-white text-blue-900 hover:bg-gray-100 font-semibold text-xs sm:text-sm whitespace-nowrap"
              >
                Assinar
              </Button>
              <Button 
                variant="outline"
                size="sm"
                onClick={() => window.open("https://wa.me/5511987654321", "_blank")}
                className="border-white text-white hover:bg-white/10 text-xs sm:text-sm whitespace-nowrap"
              >
                Fale com um especialista
              </Button>
              <Button 
                variant="ghost"
                size="sm"
                onClick={() => setLocation("/app/subscription")}
                className="text-white hover:bg-white/10 text-xs sm:text-sm whitespace-nowrap"
              >
                Ativar
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setDismissed(true)}
                className="text-white hover:bg-white/10 h-8 w-8 ml-2"
                aria-label="Fechar"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
