import { useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";

interface ProtectedRouteProps {
  children: React.ReactNode;
  requiredRoles?: Array<"OWNER" | "ADMIN" | "CUSTOMER">;
}

export default function ProtectedRoute({ children, requiredRoles }: ProtectedRouteProps) {
  const [, setLocation] = useLocation();

  const { data: user, isLoading } = useQuery({
    queryKey: ["/api/auth/me"],
    queryFn: async () => {
      const res = await fetch("/api/auth/me", { credentials: "include" });
      if (!res.ok) return null;
      const data = await res.json();
      return data.user;
    },
    retry: false,
  });

  useEffect(() => {
    if (!isLoading && !user) {
      // User not authenticated, redirect to login
      setLocation("/login");
      return;
    }

    if (!isLoading && user && requiredRoles && !requiredRoles.includes(user.role)) {
      // User doesn't have required role, redirect to appropriate dashboard
      if (user.role === "OWNER") {
        setLocation("/app/owner-dashboard");
      } else if (user.role === "ADMIN") {
        setLocation("/app/admin-dashboard");
      } else {
        setLocation("/app/dashboard");
      }
    }
  }, [user, isLoading, requiredRoles, setLocation]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return null; // Will redirect to login
  }

  if (requiredRoles && !requiredRoles.includes(user.role)) {
    return null; // Will redirect to appropriate dashboard
  }

  return <>{children}</>;
}
