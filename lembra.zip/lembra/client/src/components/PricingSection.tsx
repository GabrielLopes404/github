import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Sparkles, Zap, Crown, Rocket } from "lucide-react";
import { useState, useRef } from "react";
import { motion, useInView, useScroll, useTransform } from "framer-motion";

const plans = [
  {
    name: "STARTER",
    icon: Rocket,
    description: "Para freelancers e pequenos negócios",
    monthlyPrice: 47,
    annualPrice: 470,
    features: [
      "Até 100 clientes",
      "Faturas ilimitadas",
      "Relatórios básicos",
      "2 usuários",
      "Suporte por email",
      "7 dias grátis"
    ],
    cta: "Começar teste grátis",
    gradient: "from-primary via-primary to-primary",
    glowColor: "rgba(6, 182, 212, 0.4)"
  },
  {
    name: "BUSINESS",
    icon: Zap,
    description: "Para empresas em crescimento",
    monthlyPrice: 147,
    annualPrice: 1470,
    popular: true,
    features: [
      "Clientes ilimitados",
      "Faturas ilimitadas",
      "Relatórios avançados",
      "Até 10 usuários",
      "API de integração",
      "Suporte prioritário",
      "Automação de cobranças",
      "7 dias grátis"
    ],
    cta: "Começar teste grátis",
    gradient: "from-primary/5 via-primary/5 to-primary/80",
    glowColor: "rgba(139, 92, 246, 0.5)"
  },
  {
    name: "ENTERPRISE",
    icon: Crown,
    description: "Para grandes organizações",
    monthlyPrice: null,
    annualPrice: null,
    features: [
      "Tudo do BUSINESS",
      "Usuários ilimitados",
      "SLA garantido",
      "Gerente de conta dedicado",
      "Onboarding personalizado",
      "Customizações sob medida"
    ],
    cta: "Falar com vendas",
    gradient: "from-primary via-primary to-primary/5",
    glowColor: "rgba(251, 146, 60, 0.4)"
  }
];

export default function PricingSection() {
  const [annual, setAnnual] = useState(false);
  const ref = useRef(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });
  
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"]
  });

  const y = useTransform(scrollYProgress, [0, 1], ["50px", "-50px"]);

  return (
    <section ref={containerRef} id="precos" className="relative py-20 sm:py-32 px-4 sm:px-6 lg:px-8 overflow-hidden">
      {/* Vibrant gradient background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-primary/5 via-primary/5 to-background" />
      
      {/* Animated orbs */}
      <motion.div
        style={{ y }}
        className="absolute top-10 right-20 w-full max-w-[500px] h-[500px] bg-gradient-to-r from-primary/20 to-primary/20 rounded-full blur-3xl"
      />
      <motion.div
        style={{ y: useTransform(scrollYProgress, [0, 1], ["-30px", "100px"]) }}
        className="absolute bottom-10 left-20 w-full max-w-[500px] h-[500px] bg-gradient-to-r from-primary/20 to-blue-500/20 rounded-full blur-3xl"
      />

      {/* Grid pattern */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(236,72,153,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(236,72,153,0.03)_1px,transparent_1px)] bg-[size:64px_64px]" />
      
      <div ref={ref} className="max-w-[1440px] mx-auto relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 1, ease: [0.25, 0.4, 0.25, 1] }}
          className="text-center mb-16"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ delay: 0.2, duration: 0.6, type: "spring" }}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-gradient-to-r from-primary/10 via-primary/10 to-primary/10 border border-primary/20 backdrop-blur-xl shadow-lg mb-8 relative overflow-hidden"
          >
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent"
              animate={{ x: ['-200%', '200%'] }}
              transition={{ duration: 2, repeat: Infinity, ease: "linear", repeatDelay: 1 }}
            />
            <Sparkles className="h-5 w-5 text-primary0" />
            <span className="text-sm font-bold bg-gradient-to-r from-primary/ via-primary to-primary/80 bg-clip-text text-transparent">
              💎 Preços Transparentes e Justos
            </span>
          </motion.div>

          <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight" data-testid="text-pricing-title">
            <span className="bg-gradient-to-r from-foreground to-foreground/90 bg-clip-text text-transparent">
              Planos feitos para
            </span>
            <br />
            <span className="relative inline-block">
              <motion.span
                className="absolute -inset-2 bg-gradient-to-r from-primary/5 via-primary to-primary/80 blur-2xl opacity-30"
                animate={{ opacity: [0.3, 0.5, 0.3] }}
                transition={{ duration: 3, repeat: Infinity }}
              />
              <span className="relative bg-gradient-to-r from-primary/ via-primary to-primary/80 bg-clip-text text-transparent">
                todos os tamanhos
              </span>
            </span>
          </h2>
          <p className="text-base sm:text-lg md:text-xl text-muted-foreground mb-10 font-light max-w-3xl mx-auto" data-testid="text-pricing-subtitle">
            Comece grátis por{" "}
            <span className="font-semibold text-foreground">7 dias</span>
            . Sem cartão de crédito. Cancele quando quiser.
          </p>
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ delay: 0.4, duration: 0.6 }}
            className="flex items-center justify-center gap-4"
          >
            <motion.span
              animate={{ scale: !annual ? 1.1 : 1 }}
              className={`text-base font-semibold transition-all duration-300 ${!annual ? 'text-foreground' : 'text-muted-foreground'}`}
            >
              Mensal
            </motion.span>
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={() => setAnnual(!annual)}
              className={`relative inline-flex h-8 w-14 items-center rounded-full transition-all duration-500 shadow-lg ${
                annual ? 'bg-gradient-to-r from-primary/5 via-primary to-primary/80' : 'bg-muted'
              }`}
              data-testid="button-pricing-toggle"
            >
              <motion.span
                layout
                className="inline-block h-6 w-6 transform rounded-full bg-white shadow-xl"
                animate={{ x: annual ? 30 : 4 }}
                transition={{ type: "spring", stiffness: 500, damping: 30 }}
              />
              {annual && (
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent"
                  animate={{ x: ['-200%', '200%'] }}
                  transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                />
              )}
            </motion.button>
            <motion.span
              animate={{ scale: annual ? 1.1 : 1 }}
              className={`text-base font-semibold transition-all duration-300 ${annual ? 'text-foreground' : 'text-muted-foreground'}`}
            >
              Anual
            </motion.span>
            <motion.div
              initial={{ opacity: 0, scale: 0.8, rotate: -5 }}
              animate={{ opacity: 1, scale: 1, rotate: 0 }}
              whileHover={{ scale: 1.1, rotate: 3 }}
              transition={{ type: "spring" }}
            >
              <Badge className="ml-2 bg-gradient-to-r from-primary via-primary to-primary/80 border-0 shadow-xl text-white px-4 py-1.5 text-sm font-bold">
                💰 Economize 20%
              </Badge>
            </motion.div>
          </motion.div>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8 max-w-7xl mx-auto">
          {plans.map((plan, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 60, rotateX: -10 }}
              animate={isInView ? { opacity: 1, y: 0, rotateX: 0 } : {}}
              transition={{ 
                delay: 0.2 + index * 0.15, 
                duration: 0.8,
                type: "spring",
                stiffness: 100
              }}
              whileHover={{ y: -16, scale: 1.03 }}
              style={{ transformStyle: 'preserve-3d', perspective: '1000px' }}
              className="relative"
            >
              <Card
                className={`p-10 relative h-full backdrop-blur-xl transition-all duration-500 overflow-hidden ${
                  plan.popular 
                    ? 'border-2 border-primary/50 bg-gradient-to-br from-primary/10 via-primary/5 to-background shadow-2xl' 
                    : 'border border-border/50 bg-gradient-to-br from-background/80 to-background/40 hover:border-primary/30 shadow-xl'
                }`}
                data-testid={`card-pricing-${index}`}
              >
                {plan.popular && (
                  <>
                    <motion.div
                      initial={{ opacity: 0, y: -20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.6, type: "spring" }}
                      className="absolute -top-5 left-0 right-0 flex justify-center"
                    >
                      <Badge className="bg-gradient-to-r from-primary via-primary/ to-primary/80 border-0 shadow-2xl px-6 py-2 text-sm font-bold whitespace-nowrap" data-testid="badge-popular">
                        <Sparkles className="h-4 w-4 mr-2 inline" />
                        MAIS POPULAR 🔥
                      </Badge>
                    </motion.div>

                    <motion.div
                      className={`absolute -inset-1 bg-gradient-to-r ${plan.gradient} rounded-lg blur-xl opacity-30`}
                      animate={{
                        opacity: [0.3, 0.5, 0.3],
                      }}
                      transition={{
                        duration: 3,
                        repeat: Infinity,
                        ease: "easeInOut"
                      }}
                    />
                  </>
                )}

                {/* Shimmer effect */}
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent opacity-0 group-hover:opacity-100"
                  animate={{
                    x: ['-200%', '200%'],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    repeatDelay: 3,
                    ease: "linear"
                  }}
                />
              
                <div className="relative z-10 space-y-8">
                  {/* Icon and name */}
                  <div className="space-y-4">
                    <motion.div
                      whileHover={{ scale: 1.1, rotate: 5 }}
                      transition={{ type: "spring", stiffness: 300 }}
                      className={`h-16 w-16 rounded-2xl bg-gradient-to-br ${plan.gradient} p-0.5 shadow-2xl`}
                      style={{ boxShadow: `0 10px 40px ${plan.glowColor}` }}
                    >
                      <div className="h-full w-full rounded-2xl bg-background/90 backdrop-blur-xl flex items-center justify-center">
                        <plan.icon className="h-8 w-8 text-foreground" />
                      </div>
                    </motion.div>

                    <div>
                      <h3 className="text-2xl md:text-3xl font-bold mb-2" data-testid={`text-plan-name-${index}`}>
                        {plan.name}
                      </h3>
                      <p className="text-muted-foreground" data-testid={`text-plan-description-${index}`}>
                        {plan.description}
                      </p>
                    </div>
                  </div>

                  {/* Price */}
                  <motion.div 
                    key={annual ? 'annual' : 'monthly'}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4 }}
                  >
                    {plan.monthlyPrice ? (
                      <>
                        <div className="flex items-baseline gap-2">
                          <span className={`text-5xl font-bold font-mono tabular-nums ${plan.popular ? `bg-gradient-to-r ${plan.gradient} bg-clip-text text-transparent` : ''}`} data-testid={`text-plan-price-${index}`}>
                            R$ {annual ? plan.annualPrice : plan.monthlyPrice}
                          </span>
                          <span className="text-lg text-muted-foreground">/{annual ? 'ano' : 'mês'}</span>
                        </div>
                        {annual && (
                          <motion.p 
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            className="text-sm text-muted-foreground mt-2"
                          >
                            R$ {(plan.annualPrice! / 12).toFixed(2)}/mês quando cobrado anualmente
                          </motion.p>
                        )}
                      </>
                    ) : (
                      <div className={`text-4xl font-bold bg-gradient-to-r ${plan.gradient} bg-clip-text text-transparent`} data-testid={`text-plan-price-${index}`}>
                        Personalizado
                      </div>
                    )}
                  </motion.div>

                  {/* CTA Button */}
                  <motion.div
                    whileHover={{ scale: 1.03 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <Button 
                      className={`w-full py-6 text-base font-semibold relative overflow-hidden ${
                        plan.popular 
                          ? `bg-gradient-to-r ${plan.gradient} shadow-2xl hover:shadow-primary/50` 
                          : 'border-2 hover:border-primary/50'
                      }`}
                      variant={plan.popular ? "default" : "outline"}
                      data-testid={`button-plan-cta-${index}`}
                    >
                      {plan.popular && (
                        <motion.div
                          className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent"
                          animate={{ x: ['-200%', '200%'] }}
                          transition={{ duration: 2, repeat: Infinity, ease: "linear", repeatDelay: 1 }}
                        />
                      )}
                      <span className="relative z-10">{plan.cta}</span>
                    </Button>
                  </motion.div>

                  {/* Features */}
                  <div className="space-y-4 pt-4 border-t border-border/50">
                    {plan.features.map((feature, featureIndex) => (
                      <motion.div 
                        key={featureIndex}
                        initial={{ opacity: 0, x: -10 }}
                        animate={isInView ? { opacity: 1, x: 0 } : {}}
                        transition={{ delay: 0.5 + index * 0.1 + featureIndex * 0.05 }}
                        whileHover={{ x: 5 }}
                        className="flex items-start gap-3 group/feature"
                        data-testid={`text-plan-feature-${index}-${featureIndex}`}
                      >
                        <motion.div
                          whileHover={{ scale: 1.3, rotate: 360 }}
                          transition={{ type: "spring", stiffness: 400, damping: 10 }}
                        >
                          <div className={`h-6 w-6 rounded-lg bg-gradient-to-br ${plan.gradient} flex items-center justify-center shadow-lg`}>
                            <Check className="h-4 w-4 text-white" strokeWidth={3} />
                          </div>
                        </motion.div>
                        <span className="text-base group-hover/feature:text-foreground transition-colors font-medium">
                          {feature}
                        </span>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Trust section */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 1, duration: 0.8 }}
          className="text-center mt-20 space-y-8"
        >
          <div className="flex flex-wrap justify-center gap-4 md:gap-8">
            {[
              { icon: '💳', text: 'Sem cartão de crédito' },
              { icon: '⚡', text: 'Setup em 2 minutos' },
              { icon: '🔒', text: 'Dados 100% seguros' },
              { icon: '🎯', text: 'Cancele quando quiser' }
            ].map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={isInView ? { opacity: 1, scale: 1 } : {}}
                transition={{ delay: 1.2 + i * 0.1 }}
                whileHover={{ scale: 1.1 }}
                className="flex items-center gap-3 px-6 py-3 rounded-full bg-gradient-to-r from-primary/10 to-primary/10 border border-primary/20 backdrop-blur-sm"
              >
                <span className="text-2xl">{item.icon}</span>
                <span className="font-semibold text-sm">{item.text}</span>
              </motion.div>
            ))}
          </div>

          <p className="text-muted-foreground text-lg">
            Mais de{" "}
            <span className="font-bold bg-gradient-to-r from-primary to-primary/ bg-clip-text text-transparent">
              12.500 empresas
            </span>
            {" "}já transformaram sua gestão financeira com LUCREI
          </p>
        </motion.div>
      </div>
    </section>
  );
}
