import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft, Lightbulb, TrendingUp, Zap, Target } from "lucide-react";
import { motion } from "framer-motion";

export default function HelpDicasPage() {
  const [, setLocation] = useLocation();
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    fetch("/api/auth/me", { credentials: "include" })
      .then(res => res.ok ? setIsAuthenticated(true) : setIsAuthenticated(false))
      .catch(() => setIsAuthenticated(false));
  }, []);

  const handleBack = () => {
    setLocation(isAuthenticated ? "/app/dashboard" : "/");
  };

  const tips = [
    {
      icon: TrendingUp,
      title: "Use Atalhos de Teclado",
      description: "Pressione 'Ctrl+K' para abrir a busca rápida e navegar mais rápido pela plataforma.",
      category: "Produtividade"
    },
    {
      icon: Zap,
      title: "Automatize a Categorização",
      description: "Configure regras automáticas para categorizar transações recorrentes e economize tempo.",
      category: "Automação"
    },
    {
      icon: Target,
      title: "Defina Metas Financeiras",
      description: "Estabeleça metas mensais de receita e acompanhe seu progresso no dashboard.",
      category: "Gestão"
    },
    {
      icon: Lightbulb,
      title: "Use Tags Inteligentes",
      description: "Organize transações com tags customizadas para análises mais detalhadas.",
      category: "Organização"
    },
    {
      icon: TrendingUp,
      title: "Reconciliação Semanal",
      description: "Faça a reconciliação bancária semanalmente para manter os dados sempre atualizados.",
      category: "Boas Práticas"
    },
    {
      icon: Zap,
      title: "Notificações Personalizadas",
      description: "Configure alertas para vencimentos, baixo saldo e outras situações importantes.",
      category: "Automação"
    },
    {
      icon: Target,
      title: "Backup Regular",
      description: "Exporte seus dados mensalmente como backup adicional de segurança.",
      category: "Segurança"
    },
    {
      icon: Lightbulb,
      title: "Analise os Relatórios",
      description: "Dedique tempo semanalmente para revisar relatórios e identificar oportunidades de melhoria.",
      category: "Gestão"
    },
    {
      icon: TrendingUp,
      title: "Integre com Bancos",
      description: "Use a importação de extratos OFX para sincronizar automaticamente com seus bancos.",
      category: "Produtividade"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-4 md:px-8 py-12">
        <Button 
          variant="ghost" 
          onClick={handleBack} 
          className="mb-8"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Voltar
        </Button>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <div className="flex justify-center mb-4">
            <div className="h-16 w-16 rounded-full bg-gradient-to-r from-primary to-primary/80 flex items-center justify-center">
              <Lightbulb className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-2xl md:text-4xl sm:text-xl md:text-3xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-primary to-primary/80 bg-clip-text text-transparent">
            Dicas e Truques
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Aproveite ao máximo o LUCREI com essas dicas práticas
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-6">
          {tips.map((tip, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.4, delay: index * 0.05 }}
            >
              <Card className="h-full hover:shadow-lg transition-all hover:-translate-y-1">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4 mb-4">
                    <div className="h-12 w-12 rounded-lg bg-gradient-to-br from-primary to-primary flex items-center justify-center flex-shrink-0">
                      <tip.icon className="h-6 w-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="text-xs text-primary font-semibold mb-1">{tip.category}</div>
                      <h3 className="font-semibold text-lg">{tip.title}</h3>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground">{tip.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
          className="mt-16"
        >
          <Card className="bg-gradient-to-r from-primary/10 to-primary/10 border-primary/20">
            <CardContent className="p-4 md:p-8 text-center">
              <h2 className="text-2xl font-bold mb-4">Quer compartilhar sua dica?</h2>
              <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
                Ajude outros usuários compartilhando suas melhores práticas
              </p>
              <Button 
                onClick={() => setLocation("/help/feedback")}
                className="bg-gradient-to-r from-primary to-primary/80"
              >
                Enviar Dica
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
